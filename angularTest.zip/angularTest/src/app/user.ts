export interface User{
    id:number;
    url:string;
  }