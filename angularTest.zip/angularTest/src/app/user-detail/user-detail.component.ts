import { Component, OnInit } from '@angular/core';
import { UsersService } from '../users.service'
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {

  ngOnInit(): void {
  }

  data: any = [];

  constructor(private user: UsersService,
    private route: ActivatedRoute) {

  }

  getUserDetails() {
     let id = this.route.snapshot.paramMap.get('id');
    this.user.getUserDetail("").subscribe(data => {
      console.warn(data);
      this.data = data
    }
  }

}
