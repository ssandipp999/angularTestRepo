import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable, of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http:HttpClient) { }

  getData()
  {
    let url="https://api.github.com/users";
    return this.http.get(url);
  }

  getUserDetail(login:string)
  {
    let url="https://api.github.com/users/" + login;
    return this.http.get(url);
    //return of(User);
  }
  
}


